//
//  AppDelegate.swift
//  Project
//
//  Created by My Huyen Nguyen Phan on 2/9/17.
//  Copyright © 2017 My Phan. All rights reserved.
//

import UIKit
import StoreKit
import PubNub

@UIApplicationMain
class AppDelegate: UIResponder, UIApplicationDelegate, PNObjectEventListener {

    let alert = UIAlertController(title: "", message: "", preferredStyle: .alert)
    var window: UIWindow?
    
    lazy var client: PubNub = {
        let config = PNConfiguration(publishKey: "pub-c-ce9d0973-1cdc-4efd-923d-ecca92a969fc", subscribeKey: "sub-c-5996a0a8-ffed-11e6-a8c8-02ee2ddab7fe")
        let pub = PubNub.clientWithConfiguration(config)
        return pub
    }()
    

    func application(_ application: UIApplication, didFinishLaunchingWithOptions launchOptions: [UIApplicationLaunchOptionsKey: Any]?) -> Bool {
        // Override point for customization after application launch.
        return true
    }

    func applicationWillResignActive(_ application: UIApplication) {
        // Sent when the application is about to move from active to inactive state. This can occur for certain types of temporary interruptions (such as an incoming phone call or SMS message) or when the user quits the application and it begins the transition to the background state.
        // Use this method to pause ongoing tasks, disable timers, and invalidate graphics rendering callbacks. Games should use this method to pause the game.
    }

    func applicationDidEnterBackground(_ application: UIApplication) {
        // Use this method to release shared resources, save user data, invalidate timers, and store enough application state information to restore your application to its current state in case it is terminated later.
        // If your application supports background execution, this method is called instead of applicationWillTerminate: when the user quits.
    }

    func applicationWillEnterForeground(_ application: UIApplication) {
        // Called as part of the transition from the background to the active state; here you can undo many of the changes made on entering the background.
    }

    func applicationDidBecomeActive(_ application: UIApplication) {
        // Restart any tasks that were paused (or not yet started) while the application was inactive. If the application was previously in the background, optionally refresh the user interface.
        //Ask user for for Apple Music access
        /*SKCloudServiceController.requestAuthorization { (status) in
            if status == .authorized {
                let controller = SKCloudServiceController()
                //Check if user is a Apple Music member
                controller.requestCapabilities(completionHandler: { (capabilities, error) in
                    if error != nil {
                        DispatchQueue.main.async(execute: {
                            self.showAlert("Capabilites error", error: "You must be an Apple Music member to use this application")
                        })
                    }
                })
            } else {
                DispatchQueue.main.async{
                    self.showAlert("Denied", error: "User has denied access to Apple Music library")
                }
            }
        }*/

        appleMusicRequestPermission()
        appleMusicCheckIfDeviceCanPlayback()
    }
    
    // Request permission from the user to access the Apple Music library
    func appleMusicRequestPermission() {
        
        SKCloudServiceController.requestAuthorization { (status:SKCloudServiceAuthorizationStatus) in
            
            switch status {
                
            case .authorized:
                
                print("All good - the user tapped 'OK', so you're clear to move forward and start playing.")
                
            case .denied:
                
                print("The user tapped 'Don't allow'. Read on about that below...")
                
            case .notDetermined:
                
                print("The user hasn't decided or it's not clear whether they've confirmed or denied.")
                
            case .restricted:
                
                print("User may be restricted; for example, if the device is in Education mode, it limits external Apple Music usage. This is similar behaviour to Denied.")
                
            }
        }
    }
    
    func appleMusicCheckIfDeviceCanPlayback() {
        let serviceController = SKCloudServiceController()
        serviceController.requestCapabilities {
            
            (capability:SKCloudServiceCapability, err:Error?) -> Void in
            
            switch capability {
                
            case SKCloudServiceCapability.musicCatalogPlayback:
                
                print("The user has an Apple Music subscription and can playback music!")
                
            case SKCloudServiceCapability.addToCloudMusicLibrary:
                
                print("The user has an Apple Music subscription, can playback music AND can add to the Cloud Music Library")
                
            default:
                print("The user doesn't have an Apple Music subscription available. Now would be a good time to prompt them to buy one?")
                
                break
            }
        }
    }

    func applicationWillTerminate(_ application: UIApplication) {
        // Called when the application is about to terminate. Save data if appropriate. See also applicationDidEnterBackground:.
    }
    
    //Dialogue showing error
    func showAlert(_ title: String, error: String) {
        let alertController = UIAlertController(title: title, message: error, preferredStyle: .alert)
        let OKAction = UIAlertAction(title: "OK", style: .default, handler: nil)
        
        alertController.addAction(OKAction)
        window?.rootViewController?.present(alertController, animated: true, completion: nil)
    }
}

