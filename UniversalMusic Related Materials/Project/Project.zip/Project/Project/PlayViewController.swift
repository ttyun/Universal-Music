//
//  PlayViewController.swift
//  Project
//
//  Created by My Huyen Nguyen Phan on 3/8/17.
//  Copyright © 2017 My Phan. All rights reserved.
//

import UIKit
import PubNub
import MediaPlayer

class PlayViewController: UIViewController, PNObjectEventListener {
    var songData : SongData?
    
    //let appDelegate: AppDelegate = UIApplication.shared.delegate as! AppDelegate
    //let controller = MPMusicPlayerController.applicationMusicPlayer()
    //let controller: MPMusicPlayerController = MPMusicPlayerController.applicationMusicPlayer()
    
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
        /*print(songData?.trackName)
        print(songData?.artistName)
        print(songData?.artWork)
        print(songData?.trackId)*/
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    
    //Recieve song data to play
    /*func client(_ client: PubNub, didReceiveMessage message: PNMessageResult) {
        if let trackId = message.data.message!["trackId"] as? String,
            let currentPlaybackTime = message.data.message!["currentPlaybackTime"] as? Double,
            let trackName = message.data.message!["trackName"] as? String,
            let artistName = message.data.message!["artistName"] as? String {
            controller.setQueueWithStoreIDs([trackId])
            controller.play()
            controller.currentPlaybackTime = currentPlaybackTime
            self.trackName.text = trackName
            self.artistName.text = artistName
        }
    }*/
    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destinationViewController.
        // Pass the selected object to the new view controller.
    }
    */

}
