//
//  ViewController.swift
//  Project
//
//  Created by My Huyen Nguyen Phan on 2/9/17.
//  Copyright © 2017 My Phan. All rights reserved.
//

import UIKit

class ViewController: UIViewController {
        
    @IBOutlet weak var searchBar: UINavigationBar!
    @IBOutlet weak var tableView: UITableView!
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view, typically from a nib.
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    
}

