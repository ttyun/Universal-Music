//
//  HomeViewController.swift
//  Project
//
//  Created by My Huyen Nguyen Phan on 3/2/17.
//  Copyright © 2017 My Phan. All rights reserved.
//

import UIKit
import Alamofire
import PubNub
import MediaPlayer

class HomeViewController: UIViewController, UITableViewDelegate, UITableViewDataSource, UISearchBarDelegate, NSURLConnectionDataDelegate, PNObjectEventListener {
    //var songData = [AppleMusic]()
    //var songData : [SongData] = []
    //var tableData = [NSDictionary]()
    var songData = [SongData]();
    var songDataList = [SongData]()
    var searchActive : Bool = false
    //var songDataList : [SongData] = []
    var tableData : NSArray = NSArray() //array to hold our table info
    let applicationMusicPlayer = MPMusicPlayerController.applicationMusicPlayer()
    
    @IBOutlet weak var tableView: UITableView!
    @IBOutlet weak var searchBar: UISearchBar!
    @IBOutlet weak var bottomView: UIView!
    @IBOutlet weak var artworkImage: UIImageView!
    
    @IBOutlet weak var play: UIButton!
    @IBOutlet weak var forward: UIButton!
    @IBOutlet weak var back: UIButton!
    
    override func viewDidLoad() {
        super.viewDidLoad()
        tableView.delegate = self
        tableView.dataSource = self
        searchBar.delegate = self
        searchBar.placeholder = "search by name, artist, etc.."

        play.setImage(UIImage.init(named: "play1"), for: UIControlState.normal)
        forward.setImage(UIImage.init(named: "forward1"), for: UIControlState.normal)
        back.setImage(UIImage.init(named: "backward1"), for: UIControlState.normal)
        //let controller: MPMusicPlayerController = MPMusicPlayerController.applicationMusicPlayer()
        //var recognizer = UISwipeGestureRecognizer(target: self, action: "didSwipe")
        //self.tableView.addGestureRecognizer(recognizer)
    }
    
    @IBAction func playButton(_ sender: UIButton) {
        let image = UIImage(named: "pause1.png")! as UIImage

        play.setImage(image, for: UIControlState.selected)
        //appleMusicPlayTrackId(ids: ["1187413947"])
        //radioButtonOne.setImage(image, forState: UIControlState.Normal)
        //play.setImage(UIImage.init(named: "pause1"), for: UIControlState.selected)
        //sender.setImage(name: "play1", for: UIControlState.Normal)
        //play.setImage(UIImage.init(named: "pause1"), for: UIControlState.selected)
    }

    func appleMusicPlayTrackId(ids:[String]) {
        applicationMusicPlayer.setQueueWithStoreIDs(ids)
        applicationMusicPlayer.play()
        
        //appleMusicPlayTrackId(ids: ["1156172689"])
        
    }
    
    func didSwipe(gestureRecognizer:UIGestureRecognizer) {
        if gestureRecognizer.state == UIGestureRecognizerState.ended {
            let swipeLocation = gestureRecognizer.location(in: self.tableView)
            if let swipedIndexPath = self.tableView.indexPathForRow(at: swipeLocation){
                if let swipedCell = self.tableView.cellForRow(at: swipedIndexPath){
                    let addedTrackAlert = UIAlertController(title: nil, message: "Added track!", preferredStyle: .alert)
                    let delay = 0.9 * Double(NSEC_PER_SEC)
                    let time = DispatchTime.now() + Double(Int64(delay)) / Double(NSEC_PER_SEC)
                    
                    print("gotta swipe them all")
                    self.present(addedTrackAlert, animated: true, completion: nil)
                    
                    DispatchQueue.main.async {
                        addedTrackAlert.dismiss(animated: true, completion: nil)
                    }
                    
                }
            }
        }
    }
    
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    
    func searchBarTextDidBeginEditing(_ searchBar: UISearchBar) {
        searchActive = true
    }
    
    func searchBarTextDidEndEditing(_ searchBar: UISearchBar) {
        searchActive = false
    }
    
    func searchBarCancelButtonClicked(_ searchBar: UISearchBar) {
        searchActive = false;
    }
    
    func searchBarSearchButtonClicked(_searchBar: UISearchBar) {
        searchActive = false;
    }
    
    func dismissSearchKeyboard() {
        self.view.endEditing(true)
    }
        
    func searchBarSearchButtonClicked(_ searchBar: UISearchBar) {
        if searchBar.text != nil {
            let search = searchBar.text!.replacingOccurrences(of: " ", with: "+")
            print("searching for: " + search);
            searchItunes(searchTerm: search)
            searchBar.resignFirstResponder()
        }
    }
    
    //Search iTunes and display results in table view
    func searchItunes(searchTerm: String) {
        //songDataList = [SongData]() //clear out the songData
        tableData = NSArray()
        
        let session =  URLSession(configuration: URLSessionConfiguration.default)
        let results = NSURLRequest(url: NSURL(string: "https://itunes.apple.com/search?term=\(searchTerm)&entity=song")! as URL)
        
        
        let currentTask: URLSessionDataTask = session.dataTask(with: results as URLRequest) { (data, response, error) -> Void in
            
            if let data = data {
                do {
                    let jsonResponse: NSDictionary = try JSONSerialization.jsonObject(with: data, options:   JSONSerialization.ReadingOptions.mutableContainers) as! NSDictionary
                    
                    let results: NSArray = (jsonResponse["results"] as? NSArray)!
                    
                    if jsonResponse.count > 0 && results.count > 0{
                        self.tableData = results
                        
                        DispatchQueue.main.async {
                            self.tableView.reloadData()
                        }
                    }
                }
                catch {
                    print("Caught Exception")
                }
            }
        }
        currentTask.resume()
    }
    
    // MARK: - Navigation

    func numberOfSections(in tableView: UITableView) -> Int {
        
        return 1;
    }
    
    //Only displaying 10 of the search items
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {

        if tableData.count < 10 {
            return tableData.count
        }
        
        return 10
    }
    
    //Display Itunes search results
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        
        let cell: UITableViewCell = UITableViewCell(style: UITableViewCellStyle.subtitle, reuseIdentifier: "HomeCell")
        let rowData: NSDictionary = self.tableData[indexPath.row] as! NSDictionary
        
        // Grab the artworkUrl60 key to get an image URL for the app's thumbnail
        let urlString: NSString = rowData["artworkUrl60"] as! NSString
        let imgURL: NSURL = NSURL(string: urlString as String)!
        let imgData = try? Data(contentsOf: imgURL as URL)
        let image = UIImage(data: imgData! as Data)
        
        //let object = songDataList[(indexPath as NSIndexPath).row]
        
        DispatchQueue.main.async {
            cell.imageView?.image = image
            cell.textLabel?.text = rowData["trackName"] as? String
            cell.detailTextLabel?.text = rowData["artistName"] as? String
        }
        
        return cell;
    }
    
    //Add song to playback queue if user selects a cell
    func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
        //let indexPath = tableView.indexPathForSelectedRow
        let cell = tableView.cellForRow(at: indexPath)

        print("printing index path")
        print(indexPath)
        //tableView.cellForRowAtIndexPath(indexPath)
        
        if let rowData : NSDictionary = self.tableData[indexPath.row] as? NSDictionary {
            //print(rowData)
            let urlString: NSString = rowData["artworkUrl60"] as! NSString
            let imgURL: NSURL = NSURL(string: urlString as String)!
            let imgData = try? Data(contentsOf: imgURL as URL)
            let image = UIImage(data: imgData! as Data)
            
            let song = SongData(String(describing: rowData["trackName"]), String(describing: rowData["artistName"]), image!, String(describing: rowData["trackId"]!))
            
            songDataList.append(song)
            artworkImage.image = image

            var index = songDataList.count - 1
        
            //print("size of songDataList")
            //print(index)
            print(songDataList[index].trackId)
            //appleMusicPlayTrackId(ids: song.trackId)
            appleMusicPlayTrackId(ids: [songDataList[index].trackId])
            //artworkImage.image = songDataList[indexPath.row].artWork
            //artworkImage.image = image
            /*print("indexpath")
            print(indexPath)
            print("cell")
            print(cell)*/
            
            //self.performSegue(withIdentifier: "showPlay", sender: cell)
            tableView.deselectRow(at: indexPath, animated: true)
        }
    }
    
    //Dialogue showing error
    func showAlert(_ title: String, error: String) {
        let alertController = UIAlertController(title: title, message: error, preferredStyle: .alert)
        let OKAction = UIAlertAction(title: "OK", style: .default, handler: nil)
        alertController.addAction(OKAction)
        
        self.present(alertController, animated: true, completion:nil)
    }
    
    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destinationViewController.
        // Pass the selected object to the new view controller.
    }
}
