//
//  AppleMusicAPI.swift
//  Project
//
//  Created by My Huyen Nguyen Phan on 3/3/17.
//  Copyright © 2017 My Phan. All rights reserved.
//

import Foundation

//class AppleMusic: NSObject, NSCoding {
class AppleMusic {
    
    var kind : String
    var artistId : UInt
    var collectionId : UInt
    var trackId : UInt
    var artistName : String
    var collectionName : String
    var trackName : String
    var artistViewUrl : String
    var collectionViewUrl : String
    var previewUrl : String
    var artworkUrl60 : String
    var artworkUrl100 : String
    var trackCount : UInt
    var trackNumber : UInt
    var trackTimeMillis : UInt
    var primaryGenreName : String
    
    
    init (_ kind : String, _ artistId : UInt, _ collectionId : UInt,
          _ trackId : UInt, _ artistName : String, _ collectionName : String,
          _ trackName : String, _ artistViewUrl : String, _ collectionViewUrl : String,
          _ previewUrl : String, artworkUrl60 : String, _ artworkUrl100 : String,
          _ trackCount : UInt, _ trackNumber : UInt, _ trackTimeMillis : UInt,
          _ primaryGenreName : String) {
        
        self.kind = kind
        self.artistId = artistId
        self.collectionId = collectionId
        self.trackId = trackId
        self.artistName = artistName
        self.collectionName = collectionName
        self.trackName = trackName
        self.artistViewUrl = artistViewUrl
        self.collectionViewUrl = collectionViewUrl
        self.previewUrl = previewUrl
        self.artworkUrl60 = artworkUrl60
        self.artworkUrl100 = artworkUrl100
        self.trackCount = trackCount
        self.trackNumber = trackNumber
        self.trackTimeMillis = trackTimeMillis
        self.primaryGenreName = primaryGenreName
    }
    
    required init?(coder aDecoder: NSCoder) {
        kind = aDecoder.decodeObject(forKey: "kind") as! String
        artistId = aDecoder.decodeObject(forKey: "artistId") as! UInt
        collectionId = aDecoder.decodeObject(forKey: "collectionId") as! UInt
        trackId = aDecoder.decodeObject(forKey: "trackId") as! UInt
        artistName = aDecoder.decodeObject(forKey: "artistName") as! String
        collectionName = aDecoder.decodeObject(forKey: "collectionName ") as! String
        trackName = aDecoder.decodeObject(forKey: "trackName") as! String
        artistViewUrl = aDecoder.decodeObject(forKey: "artistViewUrl") as! String
        collectionViewUrl = aDecoder.decodeObject(forKey: "collectionViewUrl") as! String
        previewUrl = aDecoder.decodeObject(forKey: "previewUrl") as! String
        artworkUrl60 = aDecoder.decodeObject(forKey: "artworkUrl60") as! String
        artworkUrl100 = aDecoder.decodeObject(forKey: "artworkUrl100") as! String
        trackCount = aDecoder.decodeObject(forKey: "trackCount") as! UInt
        trackNumber = aDecoder.decodeObject(forKey: "trackNumber") as! UInt
        trackTimeMillis = aDecoder.decodeObject(forKey: "trackTimeMillis") as! UInt
        primaryGenreName = aDecoder.decodeObject(forKey: "primaryGenreName") as! String

    }
    
    func encode(with aCoder: NSCoder) {
        aCoder.encode(kind, forKey: "kind")
        aCoder.encode(artistId, forKey: "artistId")
        aCoder.encode(collectionId, forKey: "collectionId")
        aCoder.encode(trackId, forKey: "trackId")
        aCoder.encode(artistName, forKey: "artistName")
        aCoder.encode(collectionName, forKey: "collectionName")
        aCoder.encode(trackName, forKey: "trackName")
        aCoder.encode(artistViewUrl, forKey: "artistViewUrl")
        aCoder.encode(collectionViewUrl, forKey: "collectionViewUrl")
        aCoder.encode(trackCount, forKey: "trackCount")
        aCoder.encode(trackNumber, forKey: "trackNumber")
        aCoder.encode(trackTimeMillis, forKey: "trackTimeMillis")
        aCoder.encode(primaryGenreName, forKey: "primaryGenreName")
    }
    
    /*override var description : String {
        get {
            return "C: \(className)  T: \(classTime)  L:\(classLoc) N:\(classNote)"
        }
    }*/
}
